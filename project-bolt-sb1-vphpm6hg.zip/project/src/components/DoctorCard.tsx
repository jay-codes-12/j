import React, { useState } from 'react';
import { Star, MapPin, Clock, Calendar } from 'lucide-react';
import { Doctor } from '../types';
import AppointmentModal from './AppointmentModal';

interface DoctorCardProps {
  doctor: Doctor;
}

const DoctorCard: React.FC<DoctorCardProps> = ({ doctor }) => {
  const [showAppointmentModal, setShowAppointmentModal] = useState(false);

  return (
    <>
      <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg">
        <div className="flex flex-col md:flex-row">
          {/* Doctor Image */}
          <div className="md:w-1/3 h-48 md:h-auto relative">
            <img 
              src={doctor.image} 
              alt={doctor.name} 
              className="w-full h-full object-cover"
            />
            <div className="absolute top-2 right-2 bg-white px-2 py-1 rounded-full text-xs font-medium text-blue-600 shadow">
              {doctor.consultationType}
            </div>
          </div>
          
          {/* Doctor Info */}
          <div className="p-4 md:p-6 md:w-2/3 flex flex-col justify-between">
            <div className="space-y-3">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">{doctor.name}</h3>
                <p className="text-blue-600 font-medium">{doctor.specialty}</p>
              </div>
              
              <div className="flex items-center space-x-1">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                <span className="text-sm font-medium text-gray-700">{doctor.rating.toFixed(1)}</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">{doctor.location}</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">{doctor.experience} years experience</span>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-gray-100 flex flex-wrap justify-between items-center">
              <div>
                <div className="text-gray-500 text-xs">Consultation Fee</div>
                <div className="text-lg font-semibold text-gray-900">${doctor.fees}</div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4 text-green-500" />
                  <span className="text-xs text-gray-600">Available on</span>
                </div>
                <div className="flex gap-1">
                  {doctor.availability.map((day, i) => (
                    <span 
                      key={i} 
                      className="px-2 py-1 text-xs bg-green-50 text-green-600 rounded"
                    >
                      {day}
                    </span>
                  ))}
                </div>
                <button
                  onClick={() => setShowAppointmentModal(true)}
                  className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  Book Appointment
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showAppointmentModal && (
        <AppointmentModal
          doctor={doctor}
          onClose={() => setShowAppointmentModal(false)}
          onSuccess={() => {
            // Handle successful booking
            setShowAppointmentModal(false);
          }}
        />
      )}
    </>
  );
};

export default DoctorCard;