export interface Doctor {
  id: number;
  name: string;
  specialty: string;
  consultationType: string;
  experience: number;
  fees: number;
  rating: number;
  image: string;
  location: string;
  availability: string[];
}

export interface FilterState {
  search: string;
  consultationType: string;
  specialties: string[];
  sortBy: 'fees' | 'experience' | '';
  sortOrder: 'asc' | 'desc';
}

export interface Appointment {
  id: string;
  doctor_id: number;
  user_id: string;
  date: string;
  time: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  created_at: string;
  doctor?: Doctor;
}

export interface TimeSlot {
  time: string;
  available: boolean;
}