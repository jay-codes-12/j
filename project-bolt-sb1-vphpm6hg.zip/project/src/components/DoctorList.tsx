import React from 'react';
import DoctorCard from './DoctorCard';
import { Doctor } from '../types';
import DoctorCardSkeleton from './DoctorCardSkeleton';

interface DoctorListProps {
  doctors: Doctor[];
  isLoading: boolean;
  currentPage: number;
  doctorsPerPage: number;
  setCurrentPage: (page: number) => void;
}

const DoctorList: React.FC<DoctorListProps> = ({ 
  doctors, 
  isLoading, 
  currentPage, 
  doctorsPerPage,
  setCurrentPage 
}) => {
  // Calculate pagination values
  const indexOfLastDoctor = currentPage * doctorsPerPage;
  const indexOfFirstDoctor = indexOfLastDoctor - doctorsPerPage;
  const currentDoctors = doctors.slice(indexOfFirstDoctor, indexOfLastDoctor);
  const totalPages = Math.ceil(doctors.length / doctorsPerPage);

  const handlePageChange = (page: number) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setCurrentPage(page);
  };

  // Generate page numbers
  const pageNumbers = [];
  for (let i = 1; i <= totalPages; i++) {
    pageNumbers.push(i);
  }

  return (
    <div className="space-y-6">
      {/* Results Count */}
      {!isLoading && (
        <div className="text-sm text-gray-600">
          {doctors.length} {doctors.length === 1 ? 'doctor' : 'doctors'} found
        </div>
      )}

      {/* Doctor List */}
      <div className="space-y-6">
        {isLoading ? (
          // Loading skeletons
          Array(3).fill(0).map((_, index) => (
            <DoctorCardSkeleton key={index} />
          ))
        ) : currentDoctors.length > 0 ? (
          // Doctor cards
          currentDoctors.map(doctor => (
            <DoctorCard key={doctor.id} doctor={doctor} />
          ))
        ) : (
          // No results message
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <p className="text-gray-500">No doctors match your search criteria.</p>
            <p className="text-sm text-gray-400 mt-2">Try adjusting your filters or search term.</p>
          </div>
        )}
      </div>

      {/* Pagination */}
      {!isLoading && totalPages > 1 && (
        <div className="flex justify-center mt-8">
          <nav className="flex items-center space-x-1">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className={`px-3 py-2 rounded-md text-sm ${
                currentPage === 1
                  ? 'text-gray-400 cursor-not-allowed'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              Previous
            </button>
            
            {pageNumbers.map(number => (
              <button
                key={number}
                onClick={() => handlePageChange(number)}
                className={`px-3 py-2 rounded-md text-sm ${
                  currentPage === number
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                {number}
              </button>
            ))}
            
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className={`px-3 py-2 rounded-md text-sm ${
                currentPage === totalPages
                  ? 'text-gray-400 cursor-not-allowed'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              Next
            </button>
          </nav>
        </div>
      )}
    </div>
  );
};

export default DoctorList;