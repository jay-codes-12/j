/*
  # Add doctors table and foreign key relationship

  1. New Tables
    - `doctors`
      - `id` (integer, primary key)
      - `name` (text)
      - `specialty` (text)
      - `consultationType` (text)
      - `experience` (integer)
      - `fees` (numeric)
      - `rating` (numeric)
      - `image` (text)
      - `location` (text)
      - `availability` (jsonb)
      - `created_at` (timestamptz)

  2. Changes
    - Add foreign key constraint from appointments.doctor_id to doctors.id
    - Enable RLS on doctors table
    - Add policies for doctors table

  3. Security
    - Enable RLS on doctors table
    - Add policy for authenticated users to read doctors data
*/

-- Create doctors table if it doesn't exist
CREATE TABLE IF NOT EXISTS doctors (
    id integer PRIMARY KEY,
    name text NOT NULL,
    specialty text NOT NULL,
    "consultationType" text NOT NULL,
    experience integer NOT NULL,
    fees numeric NOT NULL,
    rating numeric,
    image text,
    location text,
    availability jsonb,
    created_at timestamptz DEFAULT now()
);

-- Insert mock doctors data to match existing appointments
INSERT INTO doctors (id, name, specialty, "consultationType", experience, fees, rating, image, location, availability) 
VALUES 
    (1, 'Dr. Sarah Johnson', 'Cardiology', 'In-person', 10, 150, 4.8, 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg', 'New York Medical Center', '["Mon", "Wed", "Fri"]'),
    (2, 'Dr. Michael Chen', 'Neurology', 'Online', 8, 130, 4.7, 'https://images.pexels.com/photos/4173239/pexels-photo-4173239.jpeg', 'Metro Hospital', '["Tue", "Thu", "Sat"]'),
    (3, 'Dr. Emily Williams', 'Pediatrics', 'In-person', 12, 120, 4.9, 'https://images.pexels.com/photos/5214958/pexels-photo-5214958.jpeg', 'Children''s Medical Center', '["Mon", "Tue", "Wed", "Thu", "Fri"]')
ON CONFLICT (id) DO NOTHING;

-- Add foreign key constraint
ALTER TABLE appointments
DROP CONSTRAINT IF EXISTS appointments_doctor_id_fkey;

ALTER TABLE appointments
ADD CONSTRAINT appointments_doctor_id_fkey
FOREIGN KEY (doctor_id) REFERENCES doctors(id);

-- Enable RLS
ALTER TABLE doctors ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Anyone can view doctors"
    ON doctors
    FOR SELECT
    TO public
    USING (true);