import { Doctor } from '../types';

// Mock API URL - would be replaced with actual API endpoint
const API_URL = 'https://api.example.com/doctors';

// Mock data for development
const mockDoctors: Doctor[] = [
  {
    id: 1,
    name: "Dr. Sarah Johnson",
    specialty: "Cardiology",
    consultationType: "In-person",
    experience: 10,
    fees: 150,
    rating: 4.8,
    image: "https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    location: "New York Medical Center",
    availability: ["Mon", "Wed", "Fri"]
  },
  {
    id: 2,
    name: "Dr. Michael Chen",
    specialty: "Neurology",
    consultationType: "Online",
    experience: 8,
    fees: 130,
    rating: 4.7,
    image: "https://images.pexels.com/photos/4173239/pexels-photo-4173239.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    location: "Metro Hospital",
    availability: ["Tue", "Thu", "Sat"]
  },
  {
    id: 3,
    name: "Dr. Emily Williams",
    specialty: "Pediatrics",
    consultationType: "In-person",
    experience: 12,
    fees: 120,
    rating: 4.9,
    image: "https://images.pexels.com/photos/5214958/pexels-photo-5214958.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    location: "Children's Medical Center",
    availability: ["Mon", "Tue", "Wed", "Thu", "Fri"]
  },
  {
    id: 4,
    name: "Dr. Robert Martinez",
    specialty: "Orthopedics",
    consultationType: "In-person",
    experience: 15,
    fees: 180,
    rating: 4.6,
    image: "https://images.pexels.com/photos/4989131/pexels-photo-4989131.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    location: "Orthopedic Specialty Clinic",
    availability: ["Mon", "Wed", "Fri"]
  },
  {
    id: 5,
    name: "Dr. Priya Patel",
    specialty: "Dermatology",
    consultationType: "Online",
    experience: 7,
    fees: 140,
    rating: 4.8,
    image: "https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    location: "Skin Care Center",
    availability: ["Tue", "Thu", "Sat"]
  },
  {
    id: 6,
    name: "Dr. James Wilson",
    specialty: "Psychiatry",
    consultationType: "Online",
    experience: 9,
    fees: 160,
    rating: 4.7,
    image: "https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    location: "Mental Health Institute",
    availability: ["Mon", "Wed", "Fri"]
  },
  {
    id: 7,
    name: "Dr. Lisa Thompson",
    specialty: "Gynecology",
    consultationType: "In-person",
    experience: 11,
    fees: 170,
    rating: 4.9,
    image: "https://images.pexels.com/photos/5407206/pexels-photo-5407206.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    location: "Women's Health Clinic",
    availability: ["Tue", "Thu", "Sat"]
  },
  {
    id: 8,
    name: "Dr. David Lee",
    specialty: "Ophthalmology",
    consultationType: "In-person",
    experience: 14,
    fees: 190,
    rating: 4.8,
    image: "https://images.pexels.com/photos/4225880/pexels-photo-4225880.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    location: "Vision Care Center",
    availability: ["Mon", "Wed", "Fri"]
  },
  {
    id: 9,
    name: "Dr. Maria Rodriguez",
    specialty: "Cardiology",
    consultationType: "Online",
    experience: 6,
    fees: 130,
    rating: 4.6,
    image: "https://images.pexels.com/photos/5207104/pexels-photo-5207104.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    location: "Heart Institute",
    availability: ["Mon", "Tue", "Wed", "Thu", "Fri"]
  },
  {
    id: 10,
    name: "Dr. Thomas Anderson",
    specialty: "Neurology",
    consultationType: "In-person",
    experience: 13,
    fees: 175,
    rating: 4.7,
    image: "https://images.pexels.com/photos/4167541/pexels-photo-4167541.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    location: "Neurology Associates",
    availability: ["Tue", "Thu", "Sat"]
  }
];

// Function to fetch doctors from API
export const fetchDoctors = async (): Promise<Doctor[]> => {
  // In a real application, we would make an actual API call
  // return fetch(API_URL).then(response => response.json());
  
  // For this demo, we'll return mock data
  return new Promise((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      resolve(mockDoctors);
    }, 800);
  });
};

// Get all unique specialties
export const getUniqueSpecialties = (doctors: Doctor[]): string[] => {
  const specialties = doctors.map(doctor => doctor.specialty);
  return [...new Set(specialties)];
};

// Get all unique consultation types
export const getUniqueConsultationTypes = (doctors: Doctor[]): string[] => {
  const consultationTypes = doctors.map(doctor => doctor.consultationType);
  return [...new Set(consultationTypes)];
};