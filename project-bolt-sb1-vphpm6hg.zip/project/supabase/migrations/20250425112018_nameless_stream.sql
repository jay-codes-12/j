/*
  # Add doctors table and foreign key relationship

  1. New Tables
    - `doctors`
      - `id` (integer, primary key)
      - `name` (text)
      - `specialty` (text)
      - `consultationType` (text)
      - `experience` (integer)
      - `fees` (numeric)
      - `rating` (numeric)
      - `image` (text)
      - `location` (text)
      - `availability` (jsonb)
      - `created_at` (timestamptz)

  2. Changes
    - Add foreign key constraint from appointments.doctor_id to doctors.id
    - Enable RLS on doctors table
    - Add policies for doctors table

  3. Security
    - Enable RLS on doctors table
    - Add policy for authenticated users to read doctors data
*/

-- Create doctors table if it doesn't exist
CREATE TABLE IF NOT EXISTS doctors (
    id integer PRIMARY KEY,
    name text NOT NULL,
    specialty text NOT NULL,
    "consultationType" text NOT NULL,
    experience integer NOT NULL,
    fees numeric NOT NULL,
    rating numeric,
    image text,
    location text,
    availability jsonb,
    created_at timestamptz DEFAULT now()
);

-- Add foreign key constraint
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.table_constraints 
        WHERE constraint_name = 'appointments_doctor_id_fkey'
    ) THEN
        ALTER TABLE appointments
        ADD CONSTRAINT appointments_doctor_id_fkey
        FOREIGN KEY (doctor_id) REFERENCES doctors(id);
    END IF;
END $$;

-- Enable RLS
ALTER TABLE doctors ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Anyone can view doctors"
    ON doctors
    FOR SELECT
    TO public
    USING (true);