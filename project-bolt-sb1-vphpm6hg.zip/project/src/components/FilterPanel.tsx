import React from 'react';
import { Check, ChevronDown, ChevronUp, SlidersHorizontal } from 'lucide-react';
import { FilterState } from '../types';

interface FilterPanelProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  consultationTypes: string[];
  specialties: string[];
  isOpen: boolean;
  toggleOpen: () => void;
}

const FilterPanel: React.FC<FilterPanelProps> = ({ 
  filters, 
  setFilters, 
  consultationTypes, 
  specialties,
  isOpen,
  toggleOpen
}) => {
  const handleConsultationTypeChange = (type: string) => {
    setFilters(prev => ({
      ...prev,
      consultationType: prev.consultationType === type ? '' : type
    }));
  };

  const handleSpecialtyChange = (specialty: string) => {
    setFilters(prev => {
      const specialtiesList = [...prev.specialties];
      
      if (specialtiesList.includes(specialty)) {
        return {
          ...prev,
          specialties: specialtiesList.filter(item => item !== specialty)
        };
      } else {
        return {
          ...prev,
          specialties: [...specialtiesList, specialty]
        };
      }
    });
  };

  const handleSortChange = (sortBy: 'fees' | 'experience' | '') => {
    setFilters(prev => {
      // If selecting the same sort field, toggle order
      if (prev.sortBy === sortBy) {
        return {
          ...prev,
          sortOrder: prev.sortOrder === 'asc' ? 'desc' : 'asc'
        };
      }
      // Otherwise, select the new sort field with default (ascending) order
      return {
        ...prev,
        sortBy,
        sortOrder: 'asc'
      };
    });
  };

  const clearFilters = () => {
    setFilters({
      search: '',
      consultationType: '',
      specialties: [],
      sortBy: '',
      sortOrder: 'asc'
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div 
        className="flex justify-between items-center p-4 cursor-pointer bg-gray-50"
        onClick={toggleOpen}
      >
        <div className="flex items-center gap-2 font-medium text-gray-700">
          <SlidersHorizontal size={18} />
          <span>Filters & Sort</span>
        </div>
        <div className="text-gray-600">
          {isOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
        </div>
      </div>
      
      {isOpen && (
        <div className="p-4 border-t border-gray-100">
          <div className="space-y-4">
            {/* Consultation Type Selection */}
            <div>
              <h3 className="font-medium text-gray-700 mb-2">Consultation Type</h3>
              <div className="flex flex-wrap gap-2">
                {consultationTypes.map(type => (
                  <button
                    key={type}
                    onClick={() => handleConsultationTypeChange(type)}
                    className={`px-3 py-2 rounded-md text-sm transition-colors ${
                      filters.consultationType === type
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* Specialties Multi-Select */}
            <div>
              <h3 className="font-medium text-gray-700 mb-2">Specialties</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {specialties.map(specialty => (
                  <div 
                    key={specialty}
                    className="flex items-center gap-2"
                  >
                    <div 
                      onClick={() => handleSpecialtyChange(specialty)}
                      className={`h-5 w-5 rounded border cursor-pointer flex items-center justify-center ${
                        filters.specialties.includes(specialty)
                          ? 'bg-blue-600 border-blue-600'
                          : 'border-gray-300 hover:border-blue-400'
                      }`}
                    >
                      {filters.specialties.includes(specialty) && (
                        <Check size={14} className="text-white" />
                      )}
                    </div>
                    <label className="text-sm text-gray-700 cursor-pointer">
                      {specialty}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Sort Options */}
            <div>
              <h3 className="font-medium text-gray-700 mb-2">Sort By</h3>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => handleSortChange('fees')}
                  className={`px-3 py-2 rounded-md text-sm transition-colors flex items-center gap-1 ${
                    filters.sortBy === 'fees'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Fees
                  {filters.sortBy === 'fees' && (
                    filters.sortOrder === 'asc' 
                      ? <ChevronUp size={16} /> 
                      : <ChevronDown size={16} />
                  )}
                </button>
                <button
                  onClick={() => handleSortChange('experience')}
                  className={`px-3 py-2 rounded-md text-sm transition-colors flex items-center gap-1 ${
                    filters.sortBy === 'experience'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Experience
                  {filters.sortBy === 'experience' && (
                    filters.sortOrder === 'asc' 
                      ? <ChevronUp size={16} /> 
                      : <ChevronDown size={16} />
                  )}
                </button>
              </div>
            </div>

            {/* Clear Filters Button */}
            <div className="pt-2 border-t border-gray-100">
              <button
                onClick={clearFilters}
                className="text-sm text-blue-600 hover:text-blue-800"
              >
                Clear all filters
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterPanel;