/*
  # Create appointments table and related schemas

  1. New Tables
    - `appointments`
      - `id` (uuid, primary key)
      - `doctor_id` (integer, references doctors)
      - `user_id` (uuid, references auth.users)
      - `date` (date)
      - `time` (time)
      - `status` (enum)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on appointments table
    - Add policies for users to:
      - Read their own appointments
      - Create new appointments
      - Update their appointment status
*/

-- Create appointment status enum
CREATE TYPE appointment_status AS ENUM (
  'pending',
  'confirmed',
  'cancelled',
  'completed'
);

-- Create appointments table
CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id integer NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  date date NOT NULL,
  time time NOT NULL,
  status appointment_status NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  
  -- Add constraint to ensure one appointment per doctor per time slot
  UNIQUE(doctor_id, date, time)
);

-- Enable RLS
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view their own appointments"
  ON appointments
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create appointments"
  ON appointments
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own appointments"
  ON appointments
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);