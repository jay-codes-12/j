import React from 'react';

const DoctorCardSkeleton: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden animate-pulse">
      <div className="flex flex-col md:flex-row">
        {/* Doctor Image Skeleton */}
        <div className="md:w-1/3 h-48 md:h-auto bg-gray-200"></div>
        
        {/* Doctor Info Skeleton */}
        <div className="p-4 md:p-6 md:w-2/3">
          <div className="space-y-3">
            <div>
              <div className="h-6 bg-gray-200 rounded w-2/3 mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-1/3"></div>
            </div>
            
            <div className="h-4 bg-gray-200 rounded w-16"></div>
            
            <div className="h-4 bg-gray-200 rounded w-full"></div>
            
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between">
            <div>
              <div className="h-3 bg-gray-200 rounded w-20 mb-2"></div>
              <div className="h-6 bg-gray-200 rounded w-16"></div>
            </div>
            
            <div>
              <div className="h-3 bg-gray-200 rounded w-24 mb-2"></div>
              <div className="flex gap-1">
                <div className="h-6 bg-gray-200 rounded w-8"></div>
                <div className="h-6 bg-gray-200 rounded w-8"></div>
                <div className="h-6 bg-gray-200 rounded w-8"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorCardSkeleton;