import React, { useState, useEffect } from 'react';
import { Stethoscope, History, LogOut } from 'lucide-react';
import SearchBar from './components/SearchBar';
import FilterPanel from './components/FilterPanel';
import DoctorList from './components/DoctorList';
import AppointmentHistory from './components/AppointmentHistory';
import Auth from './components/Auth';
import { Doctor, FilterState } from './types';
import { 
  fetchDoctors, 
  getUniqueSpecialties, 
  getUniqueConsultationTypes 
} from './api/doctorsApi';
import { supabase } from './lib/supabase';

function App() {
  // Auth state
  const [session, setSession] = useState<boolean>(false);
  const [loading, setLoading] = useState(true);

  // State for doctors data
  const [allDoctors, setAllDoctors] = useState<Doctor[]>([]);
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [doctorNames, setDoctorNames] = useState<string[]>([]);
  const [specialties, setSpecialties] = useState<string[]>([]);
  const [consultationTypes, setConsultationTypes] = useState<string[]>([]);
  
  // State for filters
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    consultationType: '',
    specialties: [],
    sortBy: '',
    sortOrder: 'asc'
  });
  
  // State for views
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const doctorsPerPage = 5;

  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSession(!!session);
      setLoading(false);

      supabase.auth.onAuthStateChange((_event, session) => {
        setSession(!!session);
      });
    };

    checkSession();
  }, []);

  // Fetch doctors on component mount
  useEffect(() => {
    const loadDoctors = async () => {
      setIsLoading(true);
      try {
        const data = await fetchDoctors();
        setAllDoctors(data);
        setFilteredDoctors(data);
        
        // Extract unique values for filters
        setSpecialties(getUniqueSpecialties(data));
        setConsultationTypes(getUniqueConsultationTypes(data));
        
        // Extract doctor names for autocomplete
        setDoctorNames(data.map(doctor => doctor.name));
      } catch (error) {
        console.error('Error fetching doctors:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadDoctors();
  }, []);

  // Apply filters when filters change
  useEffect(() => {
    let result = [...allDoctors];
    
    // Apply search filter
    if (filters.search) {
      result = result.filter(doctor => 
        doctor.name.toLowerCase().includes(filters.search.toLowerCase())
      );
    }
    
    // Apply consultation type filter
    if (filters.consultationType) {
      result = result.filter(doctor => 
        doctor.consultationType === filters.consultationType
      );
    }
    
    // Apply specialties filter
    if (filters.specialties.length > 0) {
      result = result.filter(doctor => 
        filters.specialties.includes(doctor.specialty)
      );
    }
    
    // Apply sorting
    if (filters.sortBy) {
      result = result.sort((a, b) => {
        if (filters.sortBy === 'fees') {
          return filters.sortOrder === 'asc' ? a.fees - b.fees : b.fees - a.fees;
        } else if (filters.sortBy === 'experience') {
          return filters.sortOrder === 'asc' ? a.experience - b.experience : b.experience - a.experience;
        }
        return 0;
      });
    }
    
    setFilteredDoctors(result);
    setCurrentPage(1); // Reset to first page when filters change
  }, [filters, allDoctors]);

  // Handle search input change
  const handleSearchChange = (value: string) => {
    setFilters(prev => ({ ...prev, search: value }));
  };

  // Toggle filter panel visibility
  const toggleFilterPanel = () => {
    setIsFilterPanelOpen(prev => !prev);
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Auth onSuccess={() => setSession(true)} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Stethoscope className="h-8 w-8 text-blue-600" />
              <h1 className="ml-2 text-xl font-bold text-gray-900">DocFinder</h1>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowHistory(prev => !prev)}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
              >
                <History size={18} />
                {showHistory ? 'Find Doctors' : 'View History'}
              </button>
              <button
                onClick={handleSignOut}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-red-600 bg-red-50 rounded-md hover:bg-red-100"
              >
                <LogOut size={18} />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {showHistory ? (
          <AppointmentHistory />
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Search and Filters */}
            <div className="lg:col-span-1 space-y-6">
              <SearchBar 
                value={filters.search} 
                onChange={handleSearchChange}
                suggestions={doctorNames}
              />
              
              <FilterPanel 
                filters={filters}
                setFilters={setFilters}
                consultationTypes={consultationTypes}
                specialties={specialties}
                isOpen={isFilterPanelOpen}
                toggleOpen={toggleFilterPanel}
              />
            </div>

            {/* Right Column - Doctor List */}
            <div className="lg:col-span-2">
              <DoctorList 
                doctors={filteredDoctors}
                isLoading={isLoading}
                currentPage={currentPage}
                doctorsPerPage={doctorsPerPage}
                setCurrentPage={setCurrentPage}
              />
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-sm text-gray-500">
            © 2025 DocFinder. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;