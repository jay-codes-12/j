import React, { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { Appointment } from '../types';
import { supabase } from '../lib/supabase';

const AppointmentHistory: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('User not authenticated');

        const { data, error: fetchError } = await supabase
          .from('appointments')
          .select(`
            *,
            doctor:doctor_id (
              id,
              name,
              specialty,
              consultationType,
              experience,
              fees,
              rating,
              image,
              location,
              availability
            )
          `)
          .eq('user_id', user.id)
          .order('date', { ascending: false });

        if (fetchError) throw fetchError;
        setAppointments(data || []);
      } catch (err) {
        console.error('Error fetching appointments:', err);
        setError('Failed to load appointments');
      } finally {
        setIsLoading(false);
      }
    };

    fetchAppointments();
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white p-4 rounded-lg shadow">
            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 p-4 rounded-lg">
        <p className="text-red-800">{error}</p>
      </div>
    );
  }

  if (appointments.length === 0) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md text-center">
        <p className="text-gray-500">No appointments found</p>
        <p className="text-sm text-gray-400 mt-2">Book your first appointment to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-gray-900">Your Appointments</h2>
      
      <div className="space-y-4">
        {appointments.map((appointment) => (
          <div key={appointment.id} className="bg-white p-4 rounded-lg shadow-md">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-medium text-gray-900">
                  {appointment.doctor?.name || 'Doctor not found'}
                </h3>
                <p className="text-gray-600">{appointment.doctor?.specialty || 'Specialty not available'}</p>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}>
                {appointment.status}
              </span>
            </div>
            
            <div className="mt-4 text-sm text-gray-600">
              <p>Date: {format(new Date(appointment.date), 'MMMM d, yyyy')}</p>
              <p>Time: {appointment.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AppointmentHistory;